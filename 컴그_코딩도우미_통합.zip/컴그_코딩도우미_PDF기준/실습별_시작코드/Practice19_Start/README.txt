﻿Practice19_Start

이 프로젝트의 BUILD.cmd로 빌드하고 RUN.cmd로 실행합니다.
Practice19_Start

PDF 기준 판. 자세한 설정은 PDF_기준_새프로젝트_설정.md를 읽으세요.
먼저 강의 PDF 56~58쪽대로 GLFW/GLEW/GLM을 설치합니다. third_party는 오프라인 설치 원본입니다.
프로젝트는 Practice19_Start.vcxproj를 열고 Release/x64에서 Ctrl+F5로 실행합니다.
또는 BUILD.cmd로 빌드하고 RUN.cmd로 실행합니다.
소스는 main.cpp, vertex.glsl, fragmet.glsl 세 개입니다.
프로젝트에서 별도로 추가한 링크 항목은 opengl32.lib, glew32.lib, glfw3.lib 세 개뿐입니다.
C++17, /utf-8, /MD 강제 지정, _DEBUG 삭제, 셰이더 자동 복사는 필요하지 않습니다.
셰이더는 프로젝트 작업 폴더에서 읽습니다. EXE만 다른 곳으로 옮기지 마세요.
검색 개념을 병합하려면 도형·개념 통합 기본코드를 사용하세요.
기본코드: F1 초기화, F2 2D/3D, F3 3D 직교/원근, F4 선/면, F5 샘플 표시.
실습별 시작코드의 과제 동작은 TODO에 구현합니다.
