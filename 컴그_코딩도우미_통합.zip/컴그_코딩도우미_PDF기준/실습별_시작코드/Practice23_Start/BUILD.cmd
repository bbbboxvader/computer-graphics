@echo off
setlocal
cd /d "%~dp0"
set "VSW=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSW%" (echo Visual Studio C++ tools are required.& pause& exit /b 1)
set "MSB="
for /f "usebackq delims=" %%I in (`"%VSW%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -find MSBuild\**\Bin\MSBuild.exe`) do set "MSB=%%I"
if not defined MSB (echo MSBuild not found.& pause& exit /b 1)
"%MSB%" Practice23_Start.vcxproj /m:1 /nodeReuse:false /p:Configuration=Release /p:Platform=x64 /p:PreferredToolArchitecture=x64 /verbosity:minimal
if errorlevel 1 (pause& exit /b 1)
echo Build complete. Use RUN.cmd to run from the shader folder.
pause
