@echo off
setlocal
cd /d "%~dp0"
set "APP=bin\x64\Release\Practice10_Start\Practice10_Start.exe"
if not exist "%APP%" (echo Build the project first.& pause& exit /b 1)
"%APP%"
if errorlevel 1 pause
