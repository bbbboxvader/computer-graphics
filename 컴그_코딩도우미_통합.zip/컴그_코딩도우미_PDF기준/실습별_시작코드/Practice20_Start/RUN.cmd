@echo off
setlocal
cd /d "%~dp0"
set "APP=bin\x64\Release\Practice20_Start\Practice20_Start.exe"
if not exist "%APP%" (echo Build the project first.& pause& exit /b 1)
"%APP%"
if errorlevel 1 pause
