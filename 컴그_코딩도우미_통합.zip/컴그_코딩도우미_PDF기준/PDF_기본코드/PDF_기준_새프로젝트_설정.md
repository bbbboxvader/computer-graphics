﻿# PDF 기준으로 새 프로젝트 시작하기

기준: 지엘1 오픈지엘 기초 (1).pdf 54~59쪽, 지엘2 GLSL 기초 2 (1).pdf 9쪽,
지엘3 좌표계 변환 1 (1).pdf 2쪽.

## 컴퓨터마다 한 번: 강의 라이브러리 설치

수업에서 이미 올바르게 설치했다면 다시 설치할 필요가 없습니다.
설치 파일은 함께 제공한 third_party 안에 있으므로 인터넷 없이 준비할 수 있습니다.
아래 경로의 SDK 버전 번호는 본인 PC에 설치된 버전을 사용하세요.

1. PDF 56쪽: Windows Kits/10/Include/<SDK버전>/um/gl 폴더에 헤더를 둡니다.
   - third_party/include/GL 안의 glew.h 등 GLEW 헤더와 glfw3.h, glfw3native.h를 복사합니다.
   - GLM은 third_party/include/GL/glm 폴더 자체를 위 gl 폴더로 복사합니다.
   - 결과가 반드시 um/gl/glm/glm.hpp여야 합니다. um/gl/glm/glm/glm.hpp는 한 단계 중첩된 잘못된 배치입니다.
2. PDF 57쪽: third_party/lib/x64의 .lib를 Windows Kits/10/Lib/<SDK버전>/um/x64에 둡니다.
3. PDF 58쪽: third_party/bin/x64의 glew32.dll을 수업에서 안내한 시스템 DLL 경로에 설치합니다.
   이 배포본의 glfw3.lib는 정적 GLFW이므로 glfw3.dll은 사용하지 않습니다.
   동봉 DLL은 64비트입니다. 64비트 Windows에서는 System32가 64비트 DLL 경로입니다.
   SysWOW64에는 32비트용 DLL을 쓰므로 64비트 DLL을 두 폴더에 무조건 복사하지 마세요.

이 프로그램은 Windows SDK나 시스템 폴더를 자동으로 변경하지 않습니다.

## 새 프로젝트마다: PDF 59쪽 설정

1. Windows 데스크톱 마법사 → 콘솔 애플리케이션 → 빈 프로젝트를 만듭니다.
2. 플랫폼을 x64로 선택합니다.
3. 프로젝트 우클릭 → 속성. 구성은 모든 구성, 플랫폼은 x64로 선택합니다.
4. 링커 → 명령줄 → 추가 옵션에 아래 세 라이브러리를 추가합니다.

   opengl32.lib glew32.lib glfw3.lib

   링커 → 입력 → 추가 종속성에 같은 세 이름을 세미콜론으로 구분해 넣어도 동일합니다.
5. main.cpp, vertex.glsl, fragmet.glsl 세 파일을 프로젝트 폴더에 저장합니다.
6. CPP를 솔루션 탐색기 소스 파일에 추가합니다. main 함수가 있는 CPP는 하나만 빌드합니다.
7. Project를 시작 프로젝트로 설정 → Release/x64 선택 → Ctrl+Shift+S → Ctrl+F5.
   Release 선택은 동봉한 사전 빌드 Release 라이브러리에 맞춘 실행 방법입니다.
   Debug도 실행 가능하지만 라이브러리 런타임 경고가 남을 수 있습니다.

표준은 Visual Studio 기본값(C++14) 또는 이미 사용하던 C++20을 그대로 사용할 수 있습니다.
C++17 지정, /utf-8 추가 옵션, /MD 강제 설정, _DEBUG 삭제, 빌드 후 복사는 요구하지 않습니다.
다운로드 CPP는 한글 주석 인식을 위해 UTF-8 BOM을 포함합니다.
코드를 클립보드로 복사했다면 Visual Studio에서 인코딩 포함 저장 → UTF-8 서명 포함을 선택하세요.

## 헤더와 셰이더 경로

헤더: <GL/glew.h>, <GL/glfw3.h>, <gl/glm/glm.hpp>.
PDF처럼 현재 작업 폴더에서 ifstream으로 셰이더를 읽습니다.
Visual Studio 디버깅 → 작업 디렉터리는 기본값인 프로젝트 폴더를 유지합니다.
다르게 바꾼 적이 있다면 $(ProjectDir)로 돌려놓으세요.
EXE만 더블 클릭하면 작업 폴더가 달라질 수 있으므로 BUILD.cmd 또는 RUN.cmd를 사용하세요.
셰이더를 EXE 폴더로 자동 복사하지 않습니다.

PDF 예제의 표기는 fragment.glsl입니다. 이 프로그램은 사용자가 요청한 fragmet.glsl 표기를
세 파일 전부에 일관되게 유지합니다. fragment.glsl로 바꾸려면 실제 파일명과 CPP의 읽는 이름을 함께 바꾸세요.

## 어떤 기본코드를 선택하나요?

- PDF 기본코드: 전역 VAO/VBO, InitShader/InitBuffer/drawScene/키보드/리사이즈와 main을 직접 확인합니다.
  강의 코드에서 처음 시작하거나 새 빈 프로젝트에 세 파일을 복사할 때 사용합니다.
- 도형·개념 통합 기본코드: 도우미의 공전·도형·충돌 등 검색 코드가 사용하는 Renderer와 보조 함수를 포함합니다.
  검색한 코드를 합칠 때 사용합니다. 이 보조 함수들은 도우미가 추가한 학습용 코드입니다.
  통합 기본코드와 모든 실습 시작코드도 동일한 강의 헤더·파일 읽기·세 라이브러리 설정을 사용합니다.

## 라이브러리 경고

강의에서 사용하는 GLFW 사전 빌드 Release 라이브러리를 Debug 프로그램과 연결하면
LNK4098 런타임 경고가 나올 수 있습니다. 이를 숨기려고 /MD나 _DEBUG를 강제로 바꾸지 않습니다.
Release/x64로 실행하거나, Debug까지 경고를 없애려면 맞는 Debug 라이브러리를 준비해야 합니다.
경고와 빌드 실패는 구분하세요. 헤더 없음은 설치 배치, LNK2019는 링커 설정,
DLL 없음은 DLL 설치, shader 읽기 실패는 작업 폴더와 실제 파일명을 확인합니다.
