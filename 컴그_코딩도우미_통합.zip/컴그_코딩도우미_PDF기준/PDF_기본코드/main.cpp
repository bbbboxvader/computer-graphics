﻿// PDF 기본코드: main.cpp + vertex.glsl + fragmet.glsl
// OpenGL 기초: 창/컨텍스트/콜백/main. GLSL 기초: shader/VAO/VBO/EBO.
// 좌표계 변환: model, view, projection을 CPU에서 만들고 uniform으로 전달한다.
// 시작 전 PDF_기준_새프로젝트_설정.md 참고. 창 안에는 안내 글자를 그리지 않는다.
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <GL/glew.h>
#include <GL/glfw3.h>
#include <gl/glm/glm.hpp>
#include <gl/glm/gtc/matrix_transform.hpp>
#include <fstream>
#include <iostream>
#include <iterator>
#include <string>
#include <stdexcept>
#include <vector>
#include <cstdlib>

// [기본코드 1: 전역 상태] 숫자는 이곳에서 바꾼다. 각도 단위는 도(degree).
GLuint shaderProgramID=0, VAO=0, VBO=0, EBO=0;
int width=800, height=600;
float angle=0.0f, speed=45.0f;
glm::vec3 position(0.0f), scaleValue(1.0f), objectColor(1.0f);
bool use2D=false, orthographic=false, wire=false, paused=true;
bool dragging=false;
double previousX=0.0;
// [TODO STATE] 문제의 물체 배열/각도/속도/키 상태를 여기에 추가한다.

// 정점 하나: 좌표 xyz + 색 rgb. 같은 점을 여러 면에서 쓰므로 EBO로 정점을 재사용한다.
const GLfloat cubeVertices[]={
    -.5f,-.5f,-.5f,1,0,0,  .5f,-.5f,-.5f,0,1,0,
     .5f, .5f,-.5f,0,0,1, -.5f, .5f,-.5f,1,1,0,
    -.5f,-.5f, .5f,1,0,1,  .5f,-.5f, .5f,0,1,1,
     .5f, .5f, .5f,1,1,1, -.5f, .5f, .5f,1,.5f,0
};
const GLfloat triangleVertices[]={
    -.6f,-.5f,0,1,0,0,  .6f,-.5f,0,0,1,0,  0,.6f,0,0,0,1
};
const GLuint cubeIndices[]={
    0,2,1,0,3,2, 4,5,6,4,6,7, 0,4,7,0,7,3,
    1,2,6,1,6,5, 0,1,5,0,5,4, 3,7,6,3,6,2
};

// [GLSL 기초 2, 9쪽] 강의처럼 현재 작업 폴더의 파일을 문자열로 읽는다.
std::string filetobuf(const char* file){
    std::ifstream shaderFile(file);
    if(!shaderFile.is_open())throw std::runtime_error(std::string("Cannot read shader: ")+file);
    std::string source((std::istreambuf_iterator<char>(shaderFile)), std::istreambuf_iterator<char>());
    return source;
}

// GLSL은 C++ 빌드 때가 아니라 실행 중 GPU 드라이버가 컴파일한다.
GLuint compileShader(GLenum type,const char* file){
    std::string source=filetobuf(file);
    const GLchar* text=source.c_str();
    GLuint shader=glCreateShader(type);
    glShaderSource(shader,1,&text,nullptr);
    glCompileShader(shader);
    GLint success=GL_FALSE;
    glGetShaderiv(shader,GL_COMPILE_STATUS,&success);
    if(!success){
        char log[4096];glGetShaderInfoLog(shader,sizeof(log),nullptr,log);
        glDeleteShader(shader);throw std::runtime_error(std::string(file)+": "+log);
    }
    return shader;
}
void InitShader(){
    GLuint vertexShader=compileShader(GL_VERTEX_SHADER,"vertex.glsl");
    GLuint fragmentShader=compileShader(GL_FRAGMENT_SHADER,"fragmet.glsl");
    shaderProgramID=glCreateProgram();
    glAttachShader(shaderProgramID,vertexShader);
    glAttachShader(shaderProgramID,fragmentShader);
    glLinkProgram(shaderProgramID);
    glDeleteShader(vertexShader);glDeleteShader(fragmentShader);
    GLint success=GL_FALSE;glGetProgramiv(shaderProgramID,GL_LINK_STATUS,&success);
    if(!success){char log[4096];glGetProgramInfoLog(shaderProgramID,sizeof(log),nullptr,log);throw std::runtime_error(log);}
}
void InitBuffer(){
    glGenVertexArrays(1,&VAO);glBindVertexArray(VAO);
    glGenBuffers(1,&VBO);glBindBuffer(GL_ARRAY_BUFFER,VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(cubeVertices),cubeVertices,GL_DYNAMIC_DRAW);
    glGenBuffers(1,&EBO);glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,sizeof(cubeIndices),cubeIndices,GL_STATIC_DRAW);
    // layout(location=0): 좌표, location=1: 색. stride는 정점 하나의 전체 바이트 수.
    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,6*sizeof(GLfloat),nullptr);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,6*sizeof(GLfloat),(void*)(3*sizeof(GLfloat)));
    glEnableVertexAttribArray(1);
    glBindVertexArray(0);
    // [TODO BUFFER] 다른 도형은 정점 배열/인덱스를 만들고 VAO/VBO를 추가한다.
}
void ResetScene(){
    angle=0;position=glm::vec3(0);scaleValue=glm::vec3(1);objectColor=glm::vec3(1);
    use2D=orthographic=wire=false;paused=true;
    // [TODO RESET] 문제의 초기 상태로 복구한다.
}
void UpdateScene(float dt){
    if(!paused)angle+=speed*dt;
    // [TODO UPDATE] 속도*dt로 이동/회전. 여러 뷰포트여도 상태 갱신은 프레임당 한 번.
}
void drawScene(){
    glViewport(0,0,width,height);
    glClearColor(.08f,.10f,.15f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glUseProgram(shaderProgramID);
    // [좌표계 변환] 오른쪽 변환부터 적용한다. T*R*S = 크기 → 자전 → 이동.
    glm::mat4 model(1.0f);
    model=glm::translate(model,position);
    model=glm::rotate(model,glm::radians(angle),use2D?glm::vec3(0,0,1):glm::vec3(0,1,0));
    model=glm::scale(model,scaleValue);
    glm::mat4 view=glm::lookAt(use2D?glm::vec3(0,0,3):glm::vec3(3,2,4),glm::vec3(0),glm::vec3(0,1,0));
    float aspect=float(width)/height;
    glm::mat4 projection=(use2D||orthographic)
        ?glm::ortho(-1.5f*aspect,1.5f*aspect,-1.5f,1.5f,.1f,100.0f)
        :glm::perspective(glm::radians(45.0f),aspect,.1f,100.0f);
    // C++ 조회 이름과 vertex.glsl의 uniform 이름은 정확히 같아야 한다.
    glUniformMatrix4fv(glGetUniformLocation(shaderProgramID,"model"),1,GL_FALSE,&model[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgramID,"view"),1,GL_FALSE,&view[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgramID,"projection"),1,GL_FALSE,&projection[0][0]);
    glUniform3fv(glGetUniformLocation(shaderProgramID,"objectColor"),1,&objectColor[0]);
    glPolygonMode(GL_FRONT_AND_BACK,wire?GL_LINE:GL_FILL);
    glBindVertexArray(VAO);glBindBuffer(GL_ARRAY_BUFFER,VBO);
    if(use2D){
        glBufferSubData(GL_ARRAY_BUFFER,0,sizeof(triangleVertices),triangleVertices);
        glDrawArrays(GL_TRIANGLES,0,3); // 정점 세 개를 순서대로 사용한다.
    }else{
        glBufferSubData(GL_ARRAY_BUFFER,0,sizeof(cubeVertices),cubeVertices);
        glDrawElements(GL_TRIANGLES,36,GL_UNSIGNED_INT,nullptr); // EBO 인덱스 36개.
    }
    // [TODO DRAW] 여러 물체는 model을 다시 만들고 uniform을 보낸 뒤 반복해서 그린다.
    // 공전: R(공전각)*T(반지름)*R(자전각)*S. 부모/자식은 parent*local.
    glBindVertexArray(0);
    glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
}
void KeyCallback(GLFWwindow* window,int key,int,int action,int){
    if(action!=GLFW_PRESS)return; // 토글은 REPEAT를 무시한다.
    if(key==GLFW_KEY_ESCAPE||key==GLFW_KEY_Q)glfwSetWindowShouldClose(window,GL_TRUE);
    if(key==GLFW_KEY_F1)ResetScene();
    if(key==GLFW_KEY_F2)use2D=!use2D;
    if(key==GLFW_KEY_F3)orthographic=!orthographic;
    if(key==GLFW_KEY_F4)wire=!wire;
    if(key==GLFW_KEY_SPACE)paused=!paused;
    // [TODO KEY] 문제의 키를 추가한다. 연속 이동은 main의 폴링 또는 상태 변수로 처리한다.
}
void Reshape(GLFWwindow*,int w,int h){width=w;height=h;glViewport(0,0,w,h);}
void MouseButtonCallback(GLFWwindow* window,int button,int action,int){
    if(button==GLFW_MOUSE_BUTTON_LEFT){
        dragging=action==GLFW_PRESS;double y;glfwGetCursorPos(window,&previousX,&y);
    }
    // [TODO MOUSE] 눌림/놓기에서 선택 상태를 갱신한다.
}
void CursorPositionCallback(GLFWwindow*,double x,double){
    if(dragging)angle+=float(x-previousX)*.35f;
    previousX=x;
    // [TODO CURSOR] 화면 좌표를 과제의 좌표계로 변환해서 사용한다.
}
// 자동 실행 검사용 선택 기능. 일반 Ctrl+F5 실행에는 프레임 제한이 없다.
void SaveFrame(const char* file){
    std::vector<unsigned char> rgb(size_t(width)*height*3);
    glPixelStorei(GL_PACK_ALIGNMENT,1);glReadBuffer(GL_BACK);
    glReadPixels(0,0,width,height,GL_RGB,GL_UNSIGNED_BYTE,rgb.data());
    std::ofstream out(file,std::ios::binary);out<<"P6\n"<<width<<' '<<height<<"\n255\n";
    for(int y=height-1;y>=0;--y)out.write(reinterpret_cast<const char*>(rgb.data()+size_t(y)*width*3),width*3);
}
int main(int argc,char** argv){
    GLFWwindow* window=nullptr;
    try{
        int frames=0;const char* capture=nullptr;bool test2D=false;
        for(int i=1;i<argc;++i){
            std::string arg=argv[i];
            if(arg=="--frames"&&i+1<argc)frames=std::atoi(argv[++i]);
            else if(arg=="--capture"&&i+1<argc)capture=argv[++i];
            else if(arg=="--2d")test2D=true;
        }
        // [OpenGL 기초] GLFW → 창/컨텍스트 → GLEW → shader/buffer 순서가 중요하다.
        if(!glfwInit())throw std::runtime_error("GLFW initialization failed");
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,3);glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,3);
        glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
        if(frames>0)glfwWindowHint(GLFW_VISIBLE,GLFW_FALSE);
        window=glfwCreateWindow(width,height,"PDF Basic Code",nullptr,nullptr);
        if(!window)throw std::runtime_error("Cannot create window");
        glfwMakeContextCurrent(window);
        glewExperimental=GL_TRUE;
        if(glewInit()!=GLEW_OK)throw std::runtime_error("GLEW initialization failed");
        while(glGetError()!=GL_NO_ERROR){} // GLEW 초기화의 탐색 오류를 비운다.
        glfwSetKeyCallback(window,KeyCallback);glfwSetFramebufferSizeCallback(window,Reshape);
        glfwSetMouseButtonCallback(window,MouseButtonCallback);glfwSetCursorPosCallback(window,CursorPositionCallback);
        glfwGetFramebufferSize(window,&width,&height);
        InitShader();InitBuffer();ResetScene();use2D=test2D;
        glEnable(GL_DEPTH_TEST); // 뒤의 면이 앞의 면을 덮지 않도록 깊이를 비교한다.
        double previous=glfwGetTime();int frame=0;
        while(!glfwWindowShouldClose(window)){
            glfwPollEvents();
            double now=glfwGetTime();float dt=float(now-previous);previous=now;
            UpdateScene(dt);
            // [TODO POLL] if(glfwGetKey(window,GLFW_KEY_A)==GLFW_PRESS)position.x-=dt;
            if(width<=0||height<=0){glfwWaitEventsTimeout(.05);continue;}
            drawScene();
            if(glGetError()!=GL_NO_ERROR)throw std::runtime_error("OpenGL draw error");
            if(frames>0&&++frame>=frames){if(capture)SaveFrame(capture);glfwSetWindowShouldClose(window,GL_TRUE);}
            glfwSwapBuffers(window);
        }
        // 컨텍스트가 살아 있을 때 GPU 자원을 해제한 뒤 창을 닫는다.
        glDeleteBuffers(1,&EBO);glDeleteBuffers(1,&VBO);glDeleteVertexArrays(1,&VAO);glDeleteProgram(shaderProgramID);
        glfwDestroyWindow(window);glfwTerminate();return 0;
    }catch(const std::exception& error){
        std::cerr<<error.what()<<'\n';if(window)glfwDestroyWindow(window);glfwTerminate();return 1;
    }
}
