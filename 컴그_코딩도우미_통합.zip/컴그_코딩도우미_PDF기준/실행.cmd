@echo off
chcp 65001 >nul
start "" "%~dp0코딩도우미.html"
