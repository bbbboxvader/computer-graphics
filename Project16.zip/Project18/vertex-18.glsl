#version 330 core
layout(location = 0) in vec3 vPosition;
layout(location = 1) in vec3 vColor;
out vec3 outColor;
// uPosition은 구 하나의 위치, uSystemOffset은 태양계 전체의 이동량이다.
uniform vec3 uPosition;
uniform vec3 uSystemOffset;
uniform float uScale;
// 0이면 직각 투영, 1이면 원근 투영을 사용한다.
uniform int uPerspective;
mat4 RX(float d){float a=radians(d),c=cos(a),s=sin(a);return mat4(1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1);}
mat4 RY(float d){float a=radians(d),c=cos(a),s=sin(a);return mat4(c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1);}
mat4 Move(vec3 v){return mat4(1,0,0,0,0,1,0,0,0,0,1,0,v.x,v.y,v.z,1);}
mat4 Scale(float s){return mat4(s,0,0,0,0,s,0,0,0,0,s,0,0,0,0,1);}
void main(){
    // 세 개의 기울어진 3차원 궤도가 잘 보이도록 시점을 y축 -22도, x축 18도로 둔다.
    mat4 view=RY(-22.0)*RX(18.0);
    mat4 model=Move(uSystemOffset)*Move(uPosition)*Scale(uScale);
    vec4 position=view*model*vec4(vPosition,1.0);
    if(uPerspective==1){
        // 2.5는 카메라와 장면 사이의 기본 거리, 1.7은 원근 화면의 확대 비율이다.
        // w값을 거리에 따라 바꾸면 멀리 있는 물체가 작아지는 원근 나눗셈이 일어난다.
        float distanceFromCamera=2.5-position.z;
        gl_Position=vec4(position.x*1.7,position.y*1.7,position.z,distanceFromCamera);
    }
    else{
        gl_Position=position;
    }
    outColor=vColor;
}
